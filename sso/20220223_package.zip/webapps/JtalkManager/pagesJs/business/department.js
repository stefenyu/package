/**
 * 
 * 上海久科信息技术有限公司Copyright (C): 2012
 * 
 * 文件名称：department.js
 * 
 * 文件描述:业务分类
 * 
 * Notes: 修改历史(作者/日期/改动描述): 王彬/2012.10.04/初始化
 * 
 */
var clipboard = null;
/**  
 * Extjs消息提示框  
 * MsgTip.msg('消息标题', '消息内容');//不自动隐藏  
 * MsgTip.msg('消息标题', '消息内容',true);//默认1秒后自动隐藏  
 * MsgTip.msg('消息标题', '消息内容',true,10);//3秒后自动隐藏  
 */  
var MsgTip = function(){  
    var msgCt;  
    function createBox(t, s){  
        return ['<div class="msg" style="padding-top:350px;text-align:center">',  
                '<div class="x-box-tl"><div class="x-box-tr"><div class="x-box-tc"></div></div></div>',  
                '<div class="x-box-ml"><div class="x-box-mr"><div class="x-box-mc" style="font-size=12px;"><h3>', t, '</h3>', s, '</div></div></div>',  
                '<div class="x-box-bl"><div class="x-box-br"><div class="x-box-bc"></div></div></div>',  
                '</div>'].join('');  
    }  
    return {  
        msg : function(title, message,autoHide,pauseTime){  
            if(!msgCt){  
                msgCt = Ext.DomHelper.insertFirst(document.body, {id:'msg-div22',style:'position:absolute;top:200px;width:300px;margin:0 auto;z-index:20000;'}, true);  
            }  
            msgCt.alignTo(document, 't-t');  
            var m = Ext.DomHelper.append(msgCt, {html:createBox(title, message)}, true);  
            m.slideIn('t');  
            if(!Ext.isEmpty(autoHide)&&autoHide==true){  
             if(Ext.isEmpty(pauseTime)){  
              pauseTime=1000;  
             }  
             m.pause(pauseTime).ghost("tr", {remove:true});  
            }  
        },  
        hide:function(v){  
         var msg=Ext.get(v.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement);  
         msg.ghost("tr", {remove:true});  
        }  
    };  
}();  
Ext.onReady(function() {
	var treePanel = new Ext.ux.TreePanel({
		treeCfg : {
			id : 'treeDepartmentId',
			listeners : {
				'click' : {
					fn : function(node, e) {
					}
				}
			}
		},
		treeObjCfg : {
			url : './department.do',
			params : {
				method : 'defaultDepartmentNew'
			},
			rootText : '全部',
			rootId : '-1',
			contextmenu : [ {
				text : "添加子节点",
				icon : '。。/../style/images/icons/add0.png',
				handler : function() {
					editDepartment('add');
				}
			}, {
				text : "编辑",
				icon : '。。/../style/images/icons/edit0.gif',
				handler : function() {
					var selectedNode = Ext.getCmp('treeDepartmentId').getSelectionModel().getSelectedNode();
					if(selectedNode.id == -1 || selectedNode.id == '-1'){
						Ext.Msg.alert("提示", "根节点不能编辑");
						return false;
					}
					editDepartment('edit');
				}
			}, {
				text : "删除",
				icon : '。。/../style/images/icons/del0.gif',
				handler : function() {
					var selectedNode = Ext.getCmp('treeDepartmentId').getSelectionModel().getSelectedNode();
					if(selectedNode.id == -1 || selectedNode.id == '-1'){
						Ext.Msg.alert("提示", "根节点不能删除");
						return false;
					}
					delDepartment();
				}
			} ]
		}
	});
	treePanel.expandAll();
	new Ext.Panel({
		region : 'center',
		deferredRender : false,
		renderTo : 'departmentId',
		width : document.body.clientWidth,
		height : document.body.clientHeight,
		activeTab : 0,
		autoScroll : true,
		items : [ new Ext.Toolbar({
			autoWidth : true,
			autoShow : true,
			items : [ {
				text : "添加子节点",
				icon : '。。/../style/images/icons/add0.png',
				handler : function() {
					editDepartment('add');
				}
			}, {
				text : "编辑",
				icon : '。。/../style/images/icons/edit0.gif',
				handler : function() {
					editDepartment('edit');
				}
			}, {
				text : "删除",
				icon : '。。/../style/images/icons/del0.gif',
				handler : function() {
					delDepartment();
				}
			}, {
				text : '刷新',
				iconCls : 'bmenu',
				icon : '。。/../style/images/icons/refresh.png',
				handler : function() {
					Ext.getCmp('treeDepartmentId').getRootNode().reload();
					Ext.getCmp('treeDepartmentId').expandAll();
				}
			}, {
				text : "启用一键复制",
				iconCls : 'bcopy',
				icon : '。。/../style/images/icons/copy.png',
				handler : function() {
					copyDepartmentPk();
				}
			}, {
				text : "关闭一键复制",
				icon : '。。/../style/images/icons/copy_close.png',
				handler : function() {
					if(clipboard != null){
						clipboard.destroy();
					}
				}
			} ]
		}), treePanel ]
	});
});
/**
 * 编辑组织架构
 */
function editDepartment(method) {
	var selectedNode = Ext.getCmp('treeDepartmentId').getSelectionModel().getSelectedNode();
	var oldName = '';
	var oldSort = 0;
	var oldRank = '';

	if (null != selectedNode) {
		var formPanel = new Ext.FormPanel({
			id : "departmentformPanelId",
			labelWidth : 75, // label settings here
			frame : true,
			bodyStyle : 'padding:5px 5px 0',
			width : '100%',
			height : 130,
			defaults : {
				width : 150
			},
			defaultType : 'textfield',
			items : [ {
				id : "preNodeName",
				fieldLabel : '上级节点',
				disabled : true
			}, {
				id : 'name',
				fieldLabel : '名称',
				name : 'entity.name',
				allowBlank : false,
				regex : /^[0-9a-zA-Z_@ \/.\u4e00-\u9fa5]+$/,
				regexText : "只能输入字母、汉字、数字、下划线._@",
				maxLength : 50
			},{
				id:"sort",
				fieldLabel:'排序',
				name:'entity.sort',
				allowBlank:false,
				blankText: '只能输入数值，并不能为空',
				regex:/^[0-9]+$/,
				minValue:0
			},{
				id:"rank",
				fieldLabel:'优先级',
				name:'entity.rank',
				allowBlank:true,
				blankText: '只能输入数值',
				regex:/^[0-9]+$/,
				maxLength : 2
			}, new Ext.form.Hidden( // hidden
			{
				id : 'pk'
			}), new Ext.form.Hidden( // hidden
			{
				id : 'parentPk'
			}) ],

			buttons : [
					{
						text : '保存',
						handler : function() {
							
							if (Ext.util.Format.trim(Ext.getCmp('name').getValue()) == '') {
				                Ext.Msg.alert("提示", "名称不能为空");
				                return false;
				              }
				        	if (Ext.util.Format.trim(Ext.getCmp('name').getValue()).length>255) {
				                Ext.Msg.alert("提示", "名称最大长度为255字符");
				                return false;
				              }
							if (!Ext.getCmp('departmentformPanelId').getForm()
									.isValid()) {
								return false;
							}
							if (Ext.getCmp('name').getValue() == '') {
								Ext.Msg.alert("提示", "名称不能为空！");
								return false;
							}
							Ext.Ajax.request({
								url : './department.do',
								params : {
									method : 'saveDepartment',
									methodDepartment : method,
									name : Ext.getCmp('name').getValue(),
									pk : Ext.getCmp('pk').getValue(),
									parentPk : Ext.getCmp('parentPk').getValue(),
									sort: Ext.getCmp("sort").getValue(),
									rank: Ext.getCmp("rank").getValue(),
									oldName : oldName,
									oldRank : oldRank,
							        oldSort : oldSort
								},
								success : function(resp, option) {
									var data = Ext.util.JSON.decode(resp.responseText);
									if(data.success){
										Ext.getCmp('departmentWindowId').close();
										Ext.getCmp('treeDepartmentId')
										.getRootNode().reload();
										Ext.getCmp('treeDepartmentId').expandAll();
									}
									Ext.Msg.alert("提示", data.msg);
								}
							});
						}
					}, {
						text : '取消',
						handler : function() {
							Ext.getCmp('departmentWindowId').close();
						}
					} ]
		});

		new Ext.Window({
			id : 'departmentWindowId',
			layout : 'fit',
			width : 400,
			height : 200,
			closeAction : 'close',
			plain : true,
			modal : true,
			draggable : false,

			items : [ formPanel ]
		});
		Ext.getCmp('departmentWindowId').show();
		// 判断是添加还是编辑方法
		if (method == 'add') {
			Ext.getCmp('departmentWindowId').setTitle(
					"为" + selectedNode.text + "添加子节点");
			Ext.getCmp('parentPk').setValue(selectedNode.id);
			Ext.getCmp('preNodeName').setValue(selectedNode.text);
		} else {
			Ext.getCmp('departmentWindowId').setTitle(
					"修改" + selectedNode.text + "的信息");
			Ext.getCmp('pk').setValue(selectedNode.id);
			if (null != selectedNode.parentNode) {
				Ext.getCmp('preNodeName').setValue(
						selectedNode.parentNode.attributes.text);
				Ext.getCmp('parentPk').setValue(
						selectedNode.parentNode.attributes.id);
			
			} else {
				Ext.getCmp('preNodeName').setValue('根节点');
			}
			Ext.getCmp('sort').setValue(selectedNode.attributes.note);
			Ext.getCmp('rank').setValue(selectedNode.attributes.srcObj.rank);
			Ext.getCmp('name').setValue(selectedNode.text);
			
			oldName = Ext.getCmp('name').getValue();
			oldSort = Ext.getCmp('sort').getValue();
			oldRank = Ext.getCmp('rank').getValue();
		}
	} else {
		if (method == 'add') {
			Ext.Msg.alert("错误", "选择要添加子节点的节点!");
		} else {
			Ext.Msg.alert("错误", "选择要编辑的节点!");
		}
	}
}
/**
 * copy业务类型pk
 */
function copyDepartmentPk(){
	clipboard = new ClipboardJS('#treeDepartmentId',{  
		text: function(trigger) { 
			var selectedNode = Ext.getCmp('treeDepartmentId').getSelectionModel().getSelectedNode();
		    Ext.Msg.alert("成功", "复制成功!");
		    return selectedNode.id;  
		}
	});
}
/**
 * 删除组织架构
 */
function delDepartment() {
	var selectedNode = Ext.getCmp('treeDepartmentId').getSelectionModel()
			.getSelectedNode();
	if (null == selectedNode ) {
		Ext.Msg.alert("错误", "选择要删除的节点!");
	} else if (selectedNode.childNodes.length>0) {
		Ext.Msg.alert("错误", "该节点下存在子节点!");
	} else{
		Ext.MessageBox.confirm('提示', '确认删除?',
				function(btn) {
					if (btn == 'yes') {
						if (null != selectedNode.firstChild) {
							Ext.Msg.alert("错误", "该节点下存在子节点!");
							return;
						}
						Ext.Ajax.request({
							url : './department.do',
							params : {
								method : 'delDepartment',
								pk : selectedNode.id
							},
							success : function(ro, opt) {
								var data = Ext.util.JSON
										.decode(ro.responseText);
								if (data.success) {
									Ext.Msg.alert("提示", data.msg);
									selectedNode.parentNode.select();
									selectedNode.parentNode
											.removeChild(selectedNode);
									Ext.getCmp('treeDepartmentId')
											.getRootNode().reload();
									Ext.getCmp('treeDepartmentId').expandAll();
								} else {
									Ext.Msg.alert("提示", data.msg);
								}
							}
						});
					}
				});
	}
}