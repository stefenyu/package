(function($, undefined) {
	$(document).ready(function() {
		//var dtos = JSON.parse(dto);
		$.nclient({
			plugins:["topOption","roleCombox","normalTree","doubleRadio"],
			tools:["message","input","table","select","radio","selecttree","modal","confirm"],
			elements:[{
		          cls:"col-xs-12 col-sm-12",
		          target:".selections",
		          type:"plugin:topOption",
		          shown:5,
		          open:false,
		          options:[{
		          	type:"input",
		          	title:"客服账号",
		          	placeholder:"客服账号",
		          	id:"operatorAccount",
		          },{
		          	type:"input",
		          	title:"客服名称",
		          	placeholder:"客服名称",
		          	id:"operatorName",
		          },/*{
		          	type:"plugin:roleCombox",
		          	title:"权限组",
		          	placeholder:"权限组",
		          	multiple:true,
		          	id:"role",
		          },{
			        type:"plugin:normalTree",
			        title:"组织机构",
			        placeholder:"组织机构",
					mode:2,
			        treeType:"org",
			        id:"org"
			      },*/{
			        type:"plugin:normalTree",
			        title:"业务类型",
			        placeholder:"业务类型",
			        selectType:true,
			        treeType:"dep",
			        id:"dep"
			      },{
			          	type:"input",
			          	title:"staffId",
			          	placeholder:"staffId",
			          	id:"tag",
			          }]
		        },{
		        	id:"operatorTable",
	          target:".operatorTable",
	          type:"table",
	          jsonUrl:"./operator.do",
	          params:{
	        	  method : 'searchGrid'
	          },
	        /*  btns:[{
	        	  btnClass:".addOperator",
	  	            btnDiv: '<button class="btn btn-default addOperator" type="button" ><i class="glyphicon glyphicon-plus icon-plus"></i></button>',
	  	            btnFun: function() {},
	  	            place:"front"
	          }],*/
	          format:[{
                  title: '客服账号',
                  field: 'userName',
                  align: 'center',
                  sortable: true,
                  formatter:function(value, row, index) {
                	if (value && value.indexOf('-') > -1) {
                		value = value.split('-')[1];
            		}
          	  		return value;
      	  		}
              },{
                  title: '客服名称',
                  field: 'name',
                  align: 'center',
                  sortable: true
              },{
                  title: 'staffId',
                  field: 'tag',
                  align: 'center',
                  sortable: true
              },/*{
                  title: '权限组',
                  field: 'role',
                  align: 'center',
                  sortable: true,
                  formatter:function(value, row, index) {
                	if (null != value) {
                		return value.name;
            		}
      	  		  }
              },{
                  title: '所属组织',
                  field: 'org',
                  align: 'center',
                  sortable: true,
                  formatter:function(value, row, index) {
                	if (null != value) {
                		return value.name;
            		}
      	  		  }
              },*/{
                  title: '业务类型',
                  field: 'departmentNames',
                  align: 'center',
                  sortable: true
              },{
                  title: '自动分配',
                  field: 'autoAllocate',
                  align: 'center',
                  sortable: true,
                  formatter:function(value, row, index) {
                	  if (row.autoAllocate == '1') {
      					return '<span class="glyphicon glyphicon-ok-sign"></span>';
      				} else {
      					return '<span class="glyphicon glyphicon-remove-sign"></span>';
      				}
      	  		  }
              },{
                  title: '操作',
                  field: 'departmentIds',
                  align: 'center',
                  formatter:function(value, row, index) {
                	 /* if(isAdvancedAdmin!='true' || row.userName=="any800"){//不是超级管理员
                      	return '';
                      }else{*/
                    	return '<div style="width:80px"><span style="padding: 0 10px;" class="glyphicon glyphicon-cog"></span></div>';//<span style="padding: 0 10px;" class="glyphicon glyphicon-trash"></span>
                     /* }*/
      	  		  }
              }]
			},{
			  cls:"col-xs-12 col-sm-6",
	          target:"body",
	          id:"modalTag",
	          type:"modal",
	          body:"<form class='modalBody'></form>"
			},{
				target:".modalBody",
				type:"input",
				placeholder:"客服账号",
				title:"客服账号",
				id:"modalAccount",
				validation:{
		        	  required:true,
		        	  pattern:"^[a-z0-9_@\\.]{1,}$",
		        	  maxlength:50,
		        	  "data-validation-required-message":"客服账号不能为空！",
		        	  "data-validation-pattern-message":'客服账号仅支持输入小写字母和数字._@！',
	        		  "data-validation-maxlength-message":'客服账号最大长度为32字符'
		        }
			},/*{
				target:".modalBody",
				type:"input",
				placeholder:"客服名",
				title:"客服名",
				id:"modalName",
				validation:{
		        	  required:true,
		        	  maxlength:32,
		        	  "data-validation-required-message":"客服名不能为空",
		        	  "data-validation-maxlength-message":'客服名最大长度为32字符'
		        }
			},{
				cls:"pwd",
				target:".modalBody",
				type:"input",
				placeholder:"密码",
				title:"密码",
				id:"modalPwd",
				name:"pwd",
				validation:{
					type:"password",
					pattern:"(?!^[0-9]+$)(?!^[A-z]+$)(?!^[^A-z0-9]+$)^.{6,16}$",
					"data-validation-pattern-message":'密码必须包含数字、字符和特殊字符中的两种，长度在6——16位之间'
		        }
			},{
				target:".modalBody",
				type:"input",
				placeholder:"重复密码",
				title:"重复密码",
				id:"modalConfirmPwd",
				name:"confirmPwd",
				validation:{
					type:"password",
					"data-validation-match-match":"pwd",
					"data-validation-match-message":'重复密码与密码不一致'
		        }
			},{
				target:".modalBody",
				type:"input",
				placeholder:"邮箱地址",
				title:"邮箱地址",
				id:"modalEmail",
				validation:{
					required:true,
		        	"data-validation-required-message":"邮箱地址不能为空！",
					type:"email",
					"data-validation-email-message":'Email的格式不对，请输入(例XXX@XXX.XXX)'
		        }
			},{
				target:".modalBody",
				type:"plugin:normalTree",
				treeType:"org",
				placeholder:"所属组织",
				mode:1,
				title:"所属组织",
				id:"modalOrg",
				validation:{
					required:true,
		        	"data-validation-required-message":"所属组织不能为空！",
		        }
			},*/{
				target:".modalBody",
				type:"plugin:normalTree",
		        title:"业务类型",
		        placeholder:"业务类型",
		        mode:3,
		        selectType:true,
		        treeType:"dep",
				id:"modalDep",
				validation:{
					required:true,
		        	"data-validation-required-message":"业务类型不能为空！",
		        }
			},/*{
				target:".modalBody",
	          	type:"plugin:roleCombox",
	          	title:"权限组",
	          	placeholder:"权限组",
				id:"modalRole",
				validation:{
					required:true,
		        	"data-validation-required-message":"权限组不能为空！",
		        }
	        },{
	        	target:".modalBody",
	          	type:"plugin:doubleRadio",
	          	title:"客服状态",
	          	placeholder:"客服状态",
				id:"modalStatus",
	          	options:[{
	          		name:"status",
	          		title:"正常",
		            value:1,
		            defaultValue:true
	          	},{
	          		name:"status",
	          		title:"禁用",
		            value:0
	          	}]
	        },*/{
	        	target:".modalBody",
	          	type:"input",
	          	title:"最大分配",
	          	placeholder:"最大分配",
				id:"modalAllu",
				validation:{
					required:true,
		        	"data-validation-required-message":"最大分配不能为空！",
		        	type:"number",
		        	"data-validation-number-message":"最大分配仅支持小于100的正整数！",
		        	max:100,
		        	"data-validation-max-message":"最大分配仅支持小于100的正整数！",
		        	min:1,
		        	"data-validation-min-message":"最大分配仅支持小于100的正整数！"
		        }
	        },{
	        	target:".modalBody",
	          	type:"plugin:doubleRadio",
	          	title:"自动分配",
	          	placeholder:"自动分配",
				id:"modalAuto",
	          	options:[{
	          		name:"auto",
	          		title:"参与Participation",
		            value:1,
		            defaultValue:true
	          	},{
	          		name:"auto",
	          		title:"不参与Nonparticipation",
		            value:0
	          	}]
	        }]
		}).start().done(function(main){
			var selectedPk = "",selectedOrg="",selectedName="";
			$(".modalBody").append('<div class="controlArea"><div class="pull-right"><div class="btn btn-default">取消</div><div class="btn btn-primary">确定</div></div></div>');
			var clearModal = function(){
				selectedPk = "";
				selectedOrg="";
				selectedName="";
				$("#modalAccount").clearValue();
				//$("#modalName").clearValue();
				//$("#modalOrg").clearValue();
				//$("#modalRole").clearValue();
				$("#modalDep").clearValue();
				//$("#modalPwd").clearValue();
				//$("#modalConfirmPwd").clearValue();
				//$("#modalEmail").clearValue();
				$("#modalAllu").clearValue();
				$.radioSelect("status",1);
				$.radioSelect("auto",1);
				//$("#modalAccount").ncMethod("toggleDisabled",true);
			}
			$(".controlArea .btn.btn-default").on("click",function(){
				$("#modalTag").modalHide();
			});
			$(".controlArea .btn.btn-primary").on("click",function(){
				var list = $.validationCheck(["#modalAccount","#modalName","#modalPwd","#modalComfirmPwd","#modalEmail","#modalOrg","#modalDep","#modalAllu"])
				if(list.success==true && list.list.length>0){
					main.msg({id:"saveOperator",type:"error",message:list.list[0]});
					return;
				}
				/*if(!selectedPk && $("#modalPwd").getValue()==""){
					main.msg({id:"saveOperator",type:"error",message:"需要填写密码"});
					return;
				}
				if(!$("#modalRole").getValue().key){
					main.msg({id:"saveOperator",type:"error",message:"需要填写权限组"});
					return;
				}
				var md5pwd = $("#modalPwd").getValue()?$.md5($("#modalPwd").getValue()):"";*/
				$.ajax({
					type:"POST",
					url:"./operator.do",
					dataType:"json",
					data:{
						method : 'editOperator',
						pk:selectedPk,
						userName : $("#modalAccount").getValue(),
						name : selectedName,
						//name  :$("#modalName").getValue(),
						//password :md5pwd,
						orgPk  :selectedOrg,
						departmentPk  :$("#modalDep").ncMethod("getSelectedValue").key,
						//rolePk  :$("#modalRole").getValue().key,
						//email  :$("#modalEmail").getValue(),
						active  :$.radioGet("status")==1?1:1,
						maxChat  : $("#modalAllu").getValue(),
						autoAllocate  : $.radioGet("auto")==1?1:0,
						type  : selectedPk?1:0
					}
				}).done(function(resp){
					main.msg({id:"saveOperator",message:resp.msg,type:resp.success?"info":"error"});
					if(resp.success){
						$("#modalTag").modalHide();
						$(".selections .search").click();
					}
				}).fail(function(resp){
					main.msg({id:"saveOperator",type:"error",message:resp.msg});
				})
			})
			$(".selections").delegate(".search","click",function(){
				$("#operatorTable").ncMethod("refresh",{url:"./operator.do",params:{
					method : 'searchGrid',
					//orgPk :	$("#org").getValue().key?$("#org").getValue().key:"",
					//rolePk : $("#role").getValue().key?$("#role").getValue().key:"",
					userName : $("#operatorAccount").getValue(),
					name :$("#operatorName").getValue(),
					depPk :$("#dep").ncMethod("getSelectedValue").key?$("#dep").ncMethod("getSelectedValue").key:"",
					staffId : $("#tag").getValue()
				}})
			});
			$(".selections").delegate(".reset","click",function(){
				$("#operatorAccount").setValue("");
				$("#operatorName").setValue("");
				//$("#org").clearValue();
				$("#dep").clearValue();
				$("#tag").setValue("");
				//$("#role").clearValue()
				$("#operatorTable").ncMethod("refresh",{url:"./operator.do",params:{
					method : 'searchGrid',
					orgPk :	"",
					rolePk : "",
					userName : "",
					name :"",
					depPk :"",
					staffId : ""
				}})
			});
			$(".operatorTable").delegate("tbody td .glyphicon-cog","click",function(){
				var datas = $("#operatorTable").getValue();
				var index = $(this).parents("tr").data("index");
				if(!isNaN(Number(index)) && datas[index]){
					var data = datas[index];
					clearModal();
					selectedPk = data.pk;
					selectedOrg = data.orgPk;
					selectedName=data.name;
					var userNameStr = data.userName;
					if (userNameStr && userNameStr.indexOf('-') > -1) {
						userNameStr = userNameStr.split('-')[1];
            		}
					$("#modalAccount").setValue(userNameStr);
					$("#modalName").setValue(data.name);
					//$("#modalOrg").setValue(data.orgPk);
					//$("#modalRole").setValue(data.rolePk);
					$("#modalDep").ncMethod("setSelectedValue",data.departmentIds);
					//$("#modalEmail").setValue(data.email);
					$("#modalAllu").setValue(data.maxChat);
					$.radioSelect("status",data.active);
					$.radioSelect("auto",data.autoAllocate);
					$("#modalTag").modalShow();
					$("#modalAccount").ncMethod("toggleDisabled",false);
				}
			});
			$(".operatorTable").delegate(".fixed-table-toolbar .addOperator","click",function(){
				clearModal();
				$("#modalTag").modalShow();
			});
			
			$(".operatorTable").delegate("tbody td .glyphicon-trash","click",function(){
				var datas = $("#operatorTable").getValue();
				var index = $(this).parents("tr").data("index");
				if(!isNaN(Number(index)) && datas[index]){
					var data = datas[index];
					main.confirm({
						title: '提示',
					    content: '确认删除'+data.name+'吗?',
					    confirmButton: '确定',
					    cancelButton: '取消',
					    confirm: function(){
					    	$.ajax({dataType:"json",type:"POST",url:'./operator.do',data:{method:"delOperator",pk:data.pk,userName:data.userName}}).done(function(resp){
					    		if (resp.success) {
					    			main.msg({id:"delOperator",message:resp.msg});
					    			$("#operatorTable").clearValue();
								} else {
									main.msg({id:"delOperator",type:"error",message:resp.msg});
								}
					    	})
					    }
					})
				}
			});
			
			
		});
	})
})(jQuery);